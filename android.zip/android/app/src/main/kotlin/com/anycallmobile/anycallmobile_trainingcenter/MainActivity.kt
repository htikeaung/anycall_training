package com.anycallmobile.anycallmobile_trainingcenter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
